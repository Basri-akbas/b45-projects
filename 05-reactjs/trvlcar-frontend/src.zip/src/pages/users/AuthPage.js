import React from 'react'

const AuthPage = () => {
  return (
    <div>AuthPage</div>
  )
}

export default AuthPage