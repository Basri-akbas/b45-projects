import React from 'react'

const VehiclesPage = () => {
  return (
    <div>VehiclesPage</div>
  )
}

export default VehiclesPage